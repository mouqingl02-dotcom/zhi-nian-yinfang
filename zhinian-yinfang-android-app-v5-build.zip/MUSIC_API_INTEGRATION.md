# 枝念音坊真实歌曲生成接入

已加入 App → `/api/music/generate` 的真实歌曲生成入口，以及音频播放入口。

- App 不保存 API Key。
- API Key 只放后端环境变量 `MUSIC_API_KEY`。
- 后端必须接入实际音乐服务后才会返回 `audioUrl`。
- 未配置服务时明确提示，不伪造“已生成歌曲”。
