/** Provider adapter for POST /api/music/generate.
 * Keep MUSIC_API_KEY only on the server. Do not put it in the mobile app.
 * Wire the selected provider here and return { ok:true, audioUrl }.
 */
async function generateMusic(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ok:false,message:'Method Not Allowed'});
  const {title='',lyrics='',style='流行',instrumental=false}=req.body||{};
  if (!lyrics && !instrumental) return res.status(400).json({ok:false,message:'请先填写歌词或选择纯音乐'});
  if (!process.env.MUSIC_API_KEY) return res.status(503).json({ok:false,message:'音乐服务 API Key 尚未配置。'});
  // Provider-specific request goes here. No fake audio URL is returned.
  return res.status(501).json({ok:false,message:'音乐服务适配器待配置。',request:{title,lyrics,style,instrumental}});
}
module.exports={generateMusic};
