import React, { useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Audio } from 'expo-av';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as MediaLibrary from 'expo-media-library';
import { SafeAreaView, View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Alert, Share, Modal } from 'react-native';

const NAV = [
  { key: 'home', icon: '⌂', title: '首页' },
  { key: 'create', icon: '＋', title: '创作' },
  { key: 'tools', icon: '✦', title: '工具' },
  { key: 'music', icon: '♫', title: '乐库' },
  { key: 'community', icon: '◉', title: '社区' },
  { key: 'me', icon: '◎', title: '我的' },
];
const INITIAL_POSTS = [
  { id: 'p1', title: '今晚的风，适合写一首歌', author: '枝念创作者', likes: 0, comments: 0, commentItems: [], category: '推荐', liked: false },
  { id: 'p2', title: '把遗憾写进副歌里', author: '音乐旅人', likes: 0, comments: 0, commentItems: [], category: '热门', liked: false },
  { id: 'p3', title: '第一次完成自己的音乐作品', author: '新声计划', likes: 0, comments: 0, commentItems: [], category: '最新', liked: false },
];

function makeLyrics(idea, style) {
  const subject = idea.trim() || '那些没说出口的心事';
  const short = subject.length > 18 ? subject.slice(0, 18) : subject;
  return `《${short}》\n\n【主歌一】\n把${short}写进夜色里\n让晚风替我轻轻说起\n走过熟悉又陌生的街景\n每一步都藏着回忆\n\n【预副歌】\n如果时间能慢一点\n我想再听一次你的誓言\n\n【副歌】\n就让${short}化作一首歌\n唱给远方也唱给此刻\n那些遗憾那些炽热\n都在旋律里闪烁\n\n【主歌二】\n天边的云慢慢散开\n新的故事正向我走来\n把曾经的泪轻轻放下\n勇敢拥抱未来\n\n【副歌】\n就让${short}化作一首歌\n唱给远方也唱给此刻\n那些遗憾那些炽热\n都在旋律里闪烁\n\n【风格提示】${style}｜此内容为本地歌词草稿，尚未调用在线 AI 服务。`;
}

function Header({ title, onBack }) {
  return <View style={s.pageHeader}>{onBack ? <TouchableOpacity onPress={onBack} style={s.backBtn}><Text style={s.backText}>‹ 返回</Text></TouchableOpacity> : null}<Text style={s.pageTitle}>{title}</Text></View>;
}
function PrimaryButton({ title, onPress, disabled }) {
  return <TouchableOpacity onPress={onPress} disabled={disabled} style={[s.primaryBtn, disabled && { opacity: .45 }]}><Text style={s.primaryBtnText}>{title}</Text></TouchableOpacity>;
}
function Home({ go, works, openWork }) {
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <View style={s.header}><View><Text style={s.brand}>枝念音坊</Text><Text style={s.subBrand}>让每一个念头，都成为一首歌。</Text></View><View style={s.avatar}><Text style={s.avatarText}>枝</Text></View></View>
    <TouchableOpacity style={s.hero} onPress={() => go('create')}><Text style={s.heroSmall}>AI 音乐创作</Text><Text style={s.heroTitle}>把灵感，变成音乐</Text><Text style={s.heroDesc}>写下一段故事，记录一种心情，从这里开始创作。</Text><View style={s.heroButton}><Text style={s.heroButtonText}>开始创作  →</Text></View></TouchableOpacity>
    <Text style={s.sectionTitle}>快速创作</Text><View style={s.quickGrid}>{[['♫','AI 写歌','从灵感开始'],['✎','写歌词','创作歌词草稿'],['↻','歌曲续写','延续音乐故事'],['◈','风格灵感','探索音乐风格']].map(([icon,title,desc])=><TouchableOpacity key={title} style={s.quickCard} onPress={()=>go('create', title)}><View style={s.quickIcon}><Text style={s.quickIconText}>{icon}</Text></View><Text style={s.quickTitle}>{title}</Text><Text style={s.quickDesc}>{desc}</Text></TouchableOpacity>)}</View>
    <View style={s.sectionRow}><Text style={s.sectionTitle}>我的创作</Text><TouchableOpacity onPress={()=>go('works')}><Text style={s.linkText}>全部作品 ›</Text></TouchableOpacity></View>
    {works.length ? works.slice(0,3).map(w=><WorkRow key={w.id} work={w} onPress={()=>openWork(w)}/>) : <View style={s.emptyCard}><Text style={s.emptyIcon}>♫</Text><Text style={s.emptyTitle}>还没有作品</Text><Text style={s.emptyText}>开始第一次创作，你的作品会出现在这里。</Text><TouchableOpacity style={s.smallButton} onPress={()=>go('create')}><Text style={s.smallButtonText}>开始创作</Text></TouchableOpacity></View>}
    <View style={s.communityCard}><Text style={s.communityTitle}>枝念音乐社区</Text><Text style={s.communityText}>分享音乐、歌词和创作灵感，与喜欢音乐的人一起交流。</Text><TouchableOpacity onPress={()=>go('community')}><Text style={[s.linkText,{marginTop:12}]}>去社区看看 →</Text></TouchableOpacity></View>
  </ScrollView>;
}
function WorkRow({ work, onPress }) {
  return <TouchableOpacity style={s.workRow} onPress={onPress}><View style={s.workCover}><Text style={{fontSize:25}}>♫</Text></View><View style={{flex:1}}><Text style={s.workTitle}>{work.title}</Text><Text style={s.workMeta}>{work.style || '灵感创作'} · {work.status || '歌词草稿'}</Text><Text style={s.workMeta}>{work.date || '刚刚保存'}</Text></View><Text style={s.arrow}>›</Text></TouchableOpacity>;
}
async function requestMusicGeneration({ title, lyrics, style, instrumental, base: connectedBase, token }) {
  const base = connectedBase || process.env.EXPO_PUBLIC_API_BASE_URL;
  if (!base) return { ok: false, configured: false, message: '音乐生成后端尚未配置。' };
  const res = await fetch(`${base.replace(/\/$/, '')}/api/music/generate`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify({ title, lyrics, style, instrumental: !!instrumental }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.message || '音乐生成失败');
  return data;
}

async function backendRequest(base, token, route, options = {}) {
  const normalized = String(base || '').trim().replace(/\/$/, '');
  if (!/^https?:\/\//i.test(normalized)) throw new Error('请输入完整的后端地址，例如 http://192.168.1.10:8787');
  const response = await fetch(`${normalized}${route}`, {
    method: options.method || 'GET',
    headers: { ...(options.body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(options.body !== undefined ? { body: JSON.stringify(options.body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || data.error || `后端请求失败（${response.status}）`);
  return data;
}
function mapBackendWork(remote, local = {}) {
  return { ...local, id: remote.id, title: remote.title, idea: remote.idea || local.idea || '', lyrics: remote.lyrics || '', style: remote.genre || local.style || '流行', genre: remote.genre || local.genre || '流行', kind: remote.kind || local.kind || '歌词创作', status: local.status || remote.status || '歌词草稿', date: remote.createdAt || local.date || '刚刚保存', remoteSynced: true };
}
function mapBackendPost(remote, local = {}) {
  return { ...local, id: remote.id, title: remote.content || local.title || '社区分享', author: remote.ownerName || local.author || '枝念创作者', likes: local.likes || 0, comments: local.comments || 0, commentItems: local.commentItems || [], category: local.category || '最新', liked: !!local.liked, remoteSynced: true };
}

function Create({ initialMode, initialWork, onSave, onBack, backendSession }) {
  const [idea, setIdea] = useState(initialWork?.idea || '');
  const [style, setStyle] = useState(initialWork?.style || '流行');
  const [kind, setKind] = useState(initialWork?.kind || (initialMode === '写歌词' ? '歌词创作' : '完整歌曲'));
  const [lyrics, setLyrics] = useState(initialWork?.lyrics || '');
  const [title, setTitle] = useState(initialWork?.title || '');
  const [generatingMusic, setGeneratingMusic] = useState(false);
  const [audioUri, setAudioUri] = useState(initialWork?.audioUri || '');
  const stylesList = ['流行','民谣','R&B','摇滚','电子','古风','轻音乐','说唱'];
  const generate = () => {
    if (!idea.trim()) { Alert.alert('先写下灵感', '输入一句话或一个故事，再生成歌词草稿。'); return; }
    const text = makeLyrics(idea, style);
    setLyrics(text);
    setTitle(idea.trim().slice(0, 18));
  };
  const generateSong = async () => {
    if (!lyrics.trim()) { Alert.alert('先准备歌词', '请先生成或填写歌词。'); return; }
    setGeneratingMusic(true);
    try {
      const result = await requestMusicGeneration({ title: title.trim() || '未命名歌曲', lyrics, style, instrumental: false, base: backendSession?.base, token: backendSession?.token });
      if (!result?.audioUrl) {
        Alert.alert('音乐接口已准备', result?.message || '后端尚未配置真实音乐服务 API Key。');
        return;
      }
      setAudioUri(result.audioUrl);
      onSave({ ...(initialWork?.id ? { id: initialWork.id } : {}), title: title.trim() || '未命名歌曲', idea, style, kind, lyrics, audioUri: result.audioUrl, status: '已生成歌曲' });
      Alert.alert('歌曲生成成功', '真实音频已返回并保存到作品。');
    } catch (e) {
      Alert.alert('生成失败', e?.message || '请检查音乐服务配置。');
    } finally { setGeneratingMusic(false); }
  };

  const save = () => {
    if (!lyrics) { Alert.alert('还没有歌词', '请先生成歌词草稿。'); return; }
    onSave({ ...(initialWork?.id ? { id: initialWork.id } : {}), title: title.trim() || idea.trim().slice(0,18) || '未命名作品', idea, style, kind, lyrics, status: '歌词草稿' });
    Alert.alert('已保存', initialWork?.id ? '作品修改已保存。' : '歌词草稿已保存到「我的作品」。');
  };
  return <ScrollView style={s.page} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <Header title={initialWork ? '编辑作品' : (initialMode && initialMode !== 'AI 写歌' ? initialMode : '开始创作')} onBack={onBack}/><Text style={s.pageDesc}>{initialWork ? '修改标题、灵感或歌词后保存，作品列表会同步更新。' : '先把灵感记录下来，再逐步完善你的作品。'}</Text>
    <View style={s.createBox}><Text style={s.inputLabel}>创作灵感</Text><TextInput style={s.input} placeholder="例如：写一首关于夏夜、遗憾和重新开始的歌……" placeholderTextColor="#999" multiline value={idea} onChangeText={setIdea}/>
      <Text style={[s.inputLabel,{marginTop:16}]}>创作类型</Text><View style={s.chipRow}>{['完整歌曲','歌词创作','歌曲续写','Remix / Cover'].map(x=><TouchableOpacity key={x} onPress={()=>setKind(x)} style={[s.chip,kind===x&&s.chipActive]}><Text style={[s.chipText,kind===x&&s.chipTextActive]}>{x}</Text></TouchableOpacity>)}</View>
      <Text style={[s.inputLabel,{marginTop:16}]}>音乐风格</Text><View style={s.chipRow}>{stylesList.map(x=><TouchableOpacity key={x} onPress={()=>setStyle(x)} style={[s.chip,style===x&&s.chipActive]}><Text style={[s.chipText,style===x&&s.chipTextActive]}>{x}</Text></TouchableOpacity>)}</View>
      <PrimaryButton title={initialWork ? '重新生成歌词草稿' : '✦ 生成歌词草稿'} onPress={generate}/><Text style={s.helperText}>当前使用本地模板生成歌词草稿；在线 AI 作曲、真实音频生成及音频处理服务尚未接入。</Text>
    </View>
    {lyrics ? <View style={s.lyricsCard}><Text style={s.inputLabel}>歌词草稿</Text><TextInput value={title} onChangeText={setTitle} style={s.titleInput} placeholder="作品标题"/><TextInput multiline value={lyrics} onChangeText={setLyrics} style={s.lyricsInput}/><PrimaryButton title="保存到我的作品" onPress={save}/><PrimaryButton title={generatingMusic ? "正在生成歌曲…" : "♫ 生成真实歌曲"} onPress={generateSong} disabled={generatingMusic}/>{audioUri ? <TouchableOpacity style={s.audioReady} onPress={async()=>{const { sound }=await Audio.Sound.createAsync({uri:audioUri},{shouldPlay:true}); sound.setOnPlaybackStatusUpdate(st=>{if(st?.didJustFinish) sound.unloadAsync();});}}><Text style={s.audioReadyText}>▶ 试听已生成歌曲</Text></TouchableOpacity> : null}</View> : null}
  </ScrollView>;
}
function buildToolResult(name, raw) {
  const idea = raw.trim();
  const subject = idea || '一段关于成长与回忆的故事';
  const short = subject.length > 22 ? subject.slice(0, 22) : subject;
  if (name === '歌名生成') return [`《${short}》`, `《把${short}唱给风听》`, `《${short}之后》`, `《未寄出的${short}》`].join('\n');
  if (name === '专辑名生成') return [`《${short}》`, `《心事收藏册》`, `《沿着回忆的方向》`, `《下一页的光》`].join('\n');
  if (name === '封面创意') return `封面主题：${short}\n画面构想：夜色中的一条安静街道，远处有柔和的暖色灯光，前景留出干净的标题空间。\n色彩建议：深蓝、暖金与少量雾白。\n构图建议：主体偏下，顶部留白，适合方形专辑封面。\n提示：这是本地创意模板，不是已生成的图片。`;
  if (name === '宣传文案') return `新作品灵感｜${short}\n把说不出口的情绪，写进旋律与文字里。愿这首歌陪你走过某个平凡却难忘的瞬间。\n欢迎听听，也欢迎分享你的感受。\n#枝念音坊 #原创音乐 #音乐创作`;
  if (name === '押韵检查') {
    const lines = idea.split(/[\n，。！？；、]+/).map(x=>x.trim()).filter(Boolean);
    if (!lines.length) return '请先输入多行歌词，再检查每行的结尾字。';
    return lines.map((line,i)=>`${i+1}. ${line}\n   结尾字：${line.slice(-1)}`).join('\n\n') + '\n\n说明：当前只提取每行结尾字，尚未接入专业韵脚分析。';
  }
  if (name === '扩写 / 缩写') {
    if (!idea) return '请先输入一句歌词或创作灵感。';
    return `原文：${idea}\n\n扩写灵感：\n${idea}，让晚风把心事慢慢带远，\n把没说完的话，留给明天的晴天。\n\n精简版本：\n${short}`;
  }
  if (name === '歌词改写') {
    if (!idea) return '请先粘贴需要调整的歌词。';
    return `原文：\n${idea}\n\n改写方向参考：\n• 把抽象情绪换成具体场景和动作\n• 适当缩短长句，让句子更适合演唱\n• 在副歌重复核心意象，增强记忆点\n\n这是一份本地编辑建议，并非 AI 自动改写。`;
  }
  return `创作主题：${short}\n\n可以从人物、场景、情绪和转折四个方向继续完善。`;
}

function Tools({ openTool, onSave }) {
  const groups = [{title:'歌词工具',items:['歌词生成','歌词改写','押韵检查','扩写 / 缩写']},{title:'音乐工具',items:['歌曲续写','Remix','Cover','音乐风格调整']},{title:'音频工具',items:['人声分离','伴奏提取','音频编辑','混音辅助']},{title:'内容工具',items:['歌名生成','专辑名生成','封面创意','宣传文案']}];
  const localTools = ['歌词改写','押韵检查','扩写 / 缩写','歌名生成','专辑名生成','封面创意','宣传文案'];
  const [activeTool,setActiveTool] = useState('');
  const [source,setSource] = useState('');
  const [result,setResult] = useState('');
  const run = () => {
    if (!source.trim()) { Alert.alert('先输入内容', '输入歌词、主题或作品灵感后再生成。'); return; }
    setResult(buildToolResult(activeTool, source));
  };
  if (activeTool) return <ScrollView style={s.page} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <Header title={activeTool} onBack={()=>{setActiveTool('');setResult('');}} />
    <Text style={s.pageDesc}>本地创作辅助工具。结果为模板或编辑建议，不代表已调用在线 AI 服务。</Text>
    <View style={s.createBox}><Text style={s.inputLabel}>输入内容</Text><TextInput value={source} onChangeText={setSource} style={s.input} placeholder={activeTool==='押韵检查'?'每行输入一句歌词……':'输入主题、歌词或作品灵感……'} placeholderTextColor="#999" multiline maxLength={3000}/><PrimaryButton title="生成结果" onPress={run}/></View>
    {result ? <View style={s.lyricsCard}><Text style={s.inputLabel}>处理结果</Text><TextInput value={result} onChangeText={setResult} multiline style={s.toolResultInput}/><PrimaryButton title="保存到我的作品" onPress={()=>{onSave({title:`${activeTool}｜${source.trim().slice(0,12) || '未命名'}`,idea:source,style:'灵感工具',kind:activeTool,lyrics:result,status:'本地工具结果'});Alert.alert('已保存','工具结果已保存到「我的作品」。');}}/><PrimaryButton title="分享 / 导出文本" onPress={()=>Share.share({title:activeTool,message:result})}/></View> : null}
  </ScrollView>;
  return <ScrollView style={s.page} contentContainerStyle={s.content}><Header title="创作者工具"/><Text style={s.pageDesc}>歌词与内容工具可进行本地辅助处理；在线 AI 和音频能力需后续接入服务。</Text>{groups.map(g=><View key={g.title} style={s.toolSection}><Text style={s.toolTitle}>{g.title}</Text><View style={s.toolGrid}>{g.items.map((item,i)=><TouchableOpacity key={item} style={s.toolItem} onPress={()=>{if(localTools.includes(item)){setActiveTool(item);setSource('');setResult('');}else if(item==='歌词生成'){openTool(item);}else{Alert.alert('功能尚未接入', `${item}需要后续接入对应的 AI 或音频处理服务。`);}}}><Text style={s.toolNumber}>{String(i+1).padStart(2,'0')}</Text><Text style={s.toolItemText}>{item}</Text><Text style={s.arrow}>›</Text></TouchableOpacity>)}</View></View>)}</ScrollView>;
}
function Community({ posts, toggleLike, category, setCategory, onAddPost, onAddComment, backendConnected }) {
  const categories=['推荐','热门','最新','关注'];
  const [composerOpen,setComposerOpen]=useState(false);
  const [draftTitle,setDraftTitle]=useState('');
  const [activePost,setActivePost]=useState(null);
  const [commentText,setCommentText]=useState('');
  const visible=category==='推荐'?posts:posts.filter(p=>p.category===category || category==='关注'&&p.liked);
  const activePostData=posts.find(p=>p.id===activePost?.id) || activePost;
  const submitPost=()=>{
    const title=draftTitle.trim();
    if(!title){Alert.alert('写点内容','请输入作品或灵感标题。');return;}
    onAddPost(title);setDraftTitle('');setComposerOpen(false);
  };
  const submitComment=()=>{
    const text=commentText.trim();
    if(!text||!activePost)return;
    onAddComment(activePost.id,text);setCommentText('');
  };
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <View style={s.sectionRow}><Header title="音乐社区"/><TouchableOpacity style={s.communityComposeBtn} onPress={()=>setComposerOpen(true)}><Text style={s.communityComposeText}>＋ 发布</Text></TouchableOpacity></View>
    <Text style={s.pageDesc}>{backendConnected ? '社区发布内容已连接后端；点赞与评论目前仍保存在本机。' : '本地预览模式：社区内容仅保存在当前设备。连接后端后可同步作品与发布内容。'}</Text>
    <View style={s.tabs}>{categories.map(t=><TouchableOpacity key={t} onPress={()=>setCategory(t)} style={[s.tabBtn,category===t&&s.tabBtnActive]}><Text style={[s.tabBtnText,category===t&&s.tabBtnTextActive]}>{t}</Text></TouchableOpacity>)}</View>
    {visible.length ? visible.map(p=><View style={s.postCard} key={p.id}><View style={s.postCover}><Text style={s.postMusic}>♫</Text></View><View style={{flex:1}}><Text style={s.postTitle}>{p.title}</Text><Text style={s.postAuthor}>{p.author}</Text><View style={s.postStats}><TouchableOpacity onPress={()=>toggleLike(p.id)}><Text style={[s.stat,p.liked&&{color:'#B34B5A'}]}>{p.liked?'♥':'♡'} {p.likes}</Text></TouchableOpacity><TouchableOpacity onPress={()=>setActivePost(p)}><Text style={s.stat}>◌ {p.commentItems?.length || 0} 评论</Text></TouchableOpacity><TouchableOpacity onPress={()=>Share.share({message:p.title+'\n来自枝念音坊'})}><Text style={s.stat}>↗ 分享</Text></TouchableOpacity></View></View></View>) : <View style={s.emptyCard}><Text style={s.emptyTitle}>这里暂时没有内容</Text><Text style={s.emptyText}>点击右上角“发布”，添加一条本地社区动态。</Text></View>}
    <Modal visible={composerOpen} transparent animationType="fade" onRequestClose={()=>setComposerOpen(false)}><View style={s.modalShade}><View style={s.modalCard}><Text style={s.modalTitle}>发布社区动态</Text><TextInput value={draftTitle} onChangeText={setDraftTitle} style={s.modalInput} placeholder="分享作品名称或创作灵感……" placeholderTextColor="#999" multiline maxLength={160}/><Text style={s.modalHint}>{backendConnected ? '发布内容会保存到共享后端；点赞与评论暂为本地记录。' : '当前为本地预览，连接后端后可同步发布内容。'}</Text><View style={s.modalActions}><TouchableOpacity onPress={()=>setComposerOpen(false)} style={s.modalSecondary}><Text style={s.modalSecondaryText}>取消</Text></TouchableOpacity><TouchableOpacity onPress={submitPost} style={s.modalPrimary}><Text style={s.modalPrimaryText}>发布</Text></TouchableOpacity></View></View></View></Modal>
    <Modal visible={!!activePost} transparent animationType="slide" onRequestClose={()=>setActivePost(null)}><View style={s.modalShade}><View style={s.modalCard}><View style={s.sectionRow}><Text style={s.modalTitle}>评论</Text><TouchableOpacity onPress={()=>setActivePost(null)}><Text style={s.modalClose}>关闭</Text></TouchableOpacity></View><Text style={s.modalPostTitle}>{activePostData?.title}</Text><ScrollView style={s.commentList} keyboardShouldPersistTaps="handled">{(activePostData?.commentItems || []).length ? activePostData.commentItems.map(c=><View key={c.id} style={s.commentRow}><Text style={s.commentAuthor}>{c.author || '我'}</Text><Text style={s.commentBody}>{c.text}</Text></View>) : <Text style={s.modalHint}>还没有评论，写下第一条吧。</Text>}</ScrollView><TextInput value={commentText} onChangeText={setCommentText} style={s.commentInput} placeholder="写下你的评论……" placeholderTextColor="#999" maxLength={300}/><TouchableOpacity onPress={submitComment} style={s.modalPrimary}><Text style={s.modalPrimaryText}>发送评论</Text></TouchableOpacity></View></View></Modal>
  </ScrollView>;
}
function MusicLibrary({ tracks, onAddTrack, onRemoveTrack, works, onBack }) {
  const [title, setTitle] = useState('');
  const [uri, setUri] = useState('');
  const [playingId, setPlayingId] = useState(null);
  const [isPaused, setIsPaused] = useState(false);
  const [playMessage, setPlayMessage] = useState('从手机下载目录或已连接的 U 盘选择音频文件，即可加入本机乐库。');
  const [picking, setPicking] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [mediaTracks, setMediaTracks] = useState([]);
  const soundRef = useRef(null);
  const allTracks = [
    ...mediaTracks,
    ...works.filter(w => w.audioUri).map(w => ({ id: `work-audio-${w.id}`, title: w.title || '我的歌曲', uri: w.audioUri, source: '作品生成音频' })),
    ...tracks,
  ].filter((t, i, arr) => arr.findIndex(x => x.uri === t.uri) === i);
  useEffect(() => { scanDeviceMusic(true); return () => { if (soundRef.current) soundRef.current.unloadAsync().catch(() => {}); }; }, []);
  const scanDeviceMusic = async (quiet = false) => {
    if (scanning) return;
    setScanning(true);
    try {
      let permission = await MediaLibrary.getPermissionsAsync(false, ['audio']);
      if (!permission.granted) permission = await MediaLibrary.requestPermissionsAsync(false, ['audio']);
      if (!permission.granted) {
        setPlayMessage('尚未允许访问本机音乐。请允许枝念音坊读取音频，才能自动查找已下载歌曲。');
        if (!quiet) Alert.alert('需要音乐访问权限', '允许枝念音坊访问音频后，就能自动查找手机音乐。也可以使用下方“补充导入”选择未被系统音乐库识别的文件。');
        return;
      }
      const found = [];
      let after = undefined;
      let pages = 0;
      do {
        const page = await MediaLibrary.getAssetsAsync({ mediaType: ['audio'], first: 100, after, sortBy: [MediaLibrary.SortBy.creationTime] });
        found.push(...page.assets);
        after = page.hasNextPage ? page.endCursor : undefined;
        pages++;
      } while (after && pages < 30);
      const converted = found.map(a => ({ id: `media-${a.id}`, title: (a.filename || '本地音乐').replace(/\.[^.]+$/, ''), uri: a.uri, source: '手机音乐库', fileName: a.filename || '', size: a.size || null, mediaAssetId: a.id }));
      setMediaTracks(converted);
      setPlayMessage(converted.length ? `自动找到 ${converted.length} 首手机音乐。点击歌曲即可播放；如有歌曲未显示，可用下方“补充导入”。` : '已扫描手机音乐库，但没有找到已被系统识别的音频。请检查歌曲是否下载完成，或使用下方“补充导入”。');
      if (!quiet && !converted.length) Alert.alert('扫描完成', '没有找到系统音乐库可识别的歌曲。部分下载应用会把音乐保存在私有目录，或文件尚未被系统扫描；可用补充导入读取。');
    } catch (e) {
      setPlayMessage(`自动查找音乐失败：${e?.message || '读取手机音乐库失败'}。你仍可用补充导入选择音乐。`);
      if (!quiet) Alert.alert('扫描失败', e?.message || '无法读取手机音乐库，请检查权限。');
    } finally { setScanning(false); }
  };
  const stopCurrent = async () => {
    if (soundRef.current) { try { await soundRef.current.stopAsync(); await soundRef.current.unloadAsync(); } catch (_) {} soundRef.current = null; }
    setPlayingId(null); setIsPaused(false);
  };
  const pickLocalAudio = async () => {
    if (picking) return;
    setPicking(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: 'audio/*', multiple: true, copyToCacheDirectory: true });
      if (result.canceled || !result.assets?.length) return;
      const dir = `${FileSystem.documentDirectory}music-library/`;
      const dirInfo = await FileSystem.getInfoAsync(dir);
      if (!dirInfo.exists) await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
      let added = 0;
      let failed = 0;
      for (const asset of result.assets) {
        const safeName = String(asset.name || 'audio').replace(/[^\w.\-\u4e00-\u9fff]/g, '_').slice(-100);
        const target = `${dir}${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;
        try {
          await FileSystem.copyAsync({ from: asset.uri, to: target });
          const cleanTitle = (asset.name || '本地音乐').replace(/\.[^.]+$/, '');
          onAddTrack({ id: `local_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, title: cleanTitle, uri: target, source: '本机文件', fileName: asset.name || cleanTitle, size: asset.size || null });
          added++;
        } catch (copyError) {
          failed++;
        }
      }
      setPlayMessage(added ? `成功导入 ${added} 首${failed ? `，另有 ${failed} 首读取失败` : ''}。导入的歌曲已复制到枝念音坊应用目录，原文件不会被删除。` : '未能导入所选音频，请确认文件可读取、格式受支持且手机存储空间充足。');
      if (failed || !added) Alert.alert(added ? '部分音乐导入失败' : '导入失败', added ? `成功 ${added} 首，失败 ${failed} 首。失败的歌曲不会加入乐库，避免出现“显示已添加但无法播放”的情况。` : '无法读取所选文件。请确认文件未损坏、格式受支持、存储空间充足；也可以先用手机自带音乐播放器确认文件能否播放。');
    } catch (e) {
      Alert.alert('选择音乐失败', e?.message || '请从手机文件管理器或 U 盘重新选择音频。');
    } finally { setPicking(false); }
  };
  const playTrack = async track => {
    try {
      if (playingId === track.id && soundRef.current) { const status = await soundRef.current.getStatusAsync(); if (status.isLoaded && status.isPlaying) { await soundRef.current.pauseAsync(); setIsPaused(true); setPlayMessage(`已暂停：${track.title}。再次点击可继续播放。`); } else { await soundRef.current.playAsync(); setIsPaused(false); setPlayMessage(`正在播放：${track.title}`); } return; }
      await stopCurrent();
      await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, staysActiveInBackground: false, shouldDuckAndroid: true });
      const { sound } = await Audio.Sound.createAsync({ uri: track.uri }, { shouldPlay: true }, status => {
        if (status.isLoaded && status.didJustFinish) { setPlayingId(null); setIsPaused(false); soundRef.current = null; }
        if (status.error) setPlayMessage(`播放失败：${status.error}`);
      });
      soundRef.current = sound; setPlayingId(track.id); setIsPaused(false); setPlayMessage(`正在播放：${track.title}`);
    } catch (e) { setPlayMessage(`无法播放这首音频，可能是格式不支持或文件已移动：${e?.message || '未知错误'}`); setPlayingId(null); }
  };
  const addUrl = () => {
    const cleanTitle = title.trim() || '网络歌曲';
    const cleanUri = uri.trim();
    if (!/^https?:\/\//i.test(cleanUri)) { Alert.alert('音频链接格式不正确', '请粘贴以 http:// 或 https:// 开头、可以直接访问音频文件的链接。'); return; }
    onAddTrack({ id: `track_${Date.now()}`, title: cleanTitle, uri: cleanUri, source: '网络音频链接' });
    setTitle(''); setUri(''); setPlayMessage('网络歌曲已加入乐库。');
  };
  return <ScrollView style={s.page} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <Header title="乐库 / 音乐播放" onBack={onBack}/>
    <Text style={s.pageDesc}>先自动查找手机已下载、已被系统识别的音乐，点击歌曲即可播放。手机音乐和 U 盘原文件都不会被删除。</Text>
    <View style={s.createBox}>
      <Text style={s.inputLabel}>自动查找手机音乐</Text>
      <Text style={s.helperText}>打开乐库时自动扫描；也可以手动刷新。扫描范围受 Android 音乐权限和系统媒体索引影响。</Text>
      <PrimaryButton title={scanning ? '正在查找音乐…' : '⟳ 重新扫描本机音乐'} onPress={()=>scanDeviceMusic(false)} disabled={scanning}/>
      <Text style={[s.inputLabel,{marginTop:16}]}>补充导入（找不到的音乐再用）</Text>
      <Text style={s.helperText}>仅当歌曲未出现在自动扫描结果中，或从 U 盘选择时使用。</Text>
      <PrimaryButton title={picking ? '正在导入音乐…' : '＋ 选择音乐文件'} onPress={pickLocalAudio} disabled={picking}/>
      <Text style={[s.inputLabel,{marginTop:16}]}>可选：添加网络音频</Text>
      <TextInput value={title} onChangeText={setTitle} style={s.settingsInput} placeholder="歌曲名称（可不填）" placeholderTextColor="#999" maxLength={80}/>
      <TextInput value={uri} onChangeText={setUri} style={[s.settingsInput,{marginTop:10}]} placeholder="音频直链 https://...mp3" placeholderTextColor="#999" autoCapitalize="none" autoCorrect={false} keyboardType="url"/>
      <PrimaryButton title="＋ 添加网络音频" onPress={addUrl}/>
    </View>
    <View style={s.sectionRow}><Text style={s.sectionTitle}>我的乐库</Text><Text style={s.workMeta}>{allTracks.length} 首</Text></View>
    <View style={s.createBox}><Text style={s.helperText}>{playMessage}</Text></View>
    {allTracks.length ? allTracks.map(track => <View key={`${track.id}-${track.uri}`} style={s.workManage}>
      <TouchableOpacity style={[s.workCover,{width:48,height:48,marginRight:12}]} onPress={()=>playTrack(track)}><Text style={{fontSize:23,color:playingId===track.id&&!isPaused?'#0D9488':'#191919'}}>{playingId===track.id&&!isPaused?'Ⅱ':'♫'}</Text></TouchableOpacity>
      <View style={{flex:1}}><Text style={s.workTitle}>{track.title}</Text><Text style={s.workMeta}>{track.source || '音频'} · {playingId===track.id?(isPaused?'已暂停':'播放中'):'点击左侧播放'}</Text><Text style={s.workMeta} numberOfLines={1}>{track.fileName || track.uri}</Text></View>
      {track.mediaAssetId ? <Text style={s.workMeta}>本机</Text> : <TouchableOpacity style={s.deleteBtn} onPress={()=>{if(track.source==='作品生成音频'){Alert.alert('作品音频','此音频来自作品记录，请在作品中管理。');return;}if(playingId===track.id)stopCurrent();onRemoveTrack(track.id);}}><Text style={s.deleteText}>移除</Text></TouchableOpacity>}
    </View>) : <View style={s.emptyCard}><Text style={s.emptyIcon}>♫</Text><Text style={s.emptyTitle}>乐库还没有歌曲</Text><Text style={s.emptyText}>打开乐库后会自动查找手机音乐。若没有找到，再点“选择音乐文件”补充导入。</Text></View>}
    {playingId ? <PrimaryButton title="■ 停止播放" onPress={stopCurrent}/> : null}
  </ScrollView>;
}

function Me({ go, works, nickname }) {
  const menu=[['我的作品','works'],['我的收藏','favorites'],['创作记录','history'],['账户设置','settings']];
  return <ScrollView style={s.page} contentContainerStyle={s.content}><View style={s.profile}><View style={s.bigAvatar}><Text style={s.bigAvatarText}>枝</Text></View><Text style={s.profileName}>{nickname || '我的枝念'}</Text><Text style={s.profileDesc}>记录每一个音乐灵感</Text></View><View style={s.statsBox}><View style={s.statBoxItem}><Text style={s.statBig}>{works.length}</Text><Text style={s.statLabel}>作品</Text></View><View style={s.statBoxItem}><Text style={s.statBig}>{works.filter(w=>w.favorite).length}</Text><Text style={s.statLabel}>收藏</Text></View><View style={s.statBoxItem}><Text style={s.statBig}>0</Text><Text style={s.statLabel}>关注</Text></View><View style={s.statBoxItem}><Text style={s.statBig}>0</Text><Text style={s.statLabel}>粉丝</Text></View></View><View style={s.menuCard}>{menu.map(([title,key])=><TouchableOpacity key={key} style={s.menuItem} onPress={()=>go(key)}><Text style={s.menuItemText}>{title}</Text><Text style={s.arrow}>›</Text></TouchableOpacity>)}</View><Text style={s.helperText}>可在“账户设置”中连接共享后端；真实 AI 音乐生成、关注和粉丝功能仍需后续接入。</Text></ScrollView>;
}
function Works({ works, onOpen, onDelete, onBack }) {
  return <ScrollView style={s.page} contentContainerStyle={s.content}><Header title="我的作品" onBack={onBack}/><Text style={s.pageDesc}>保存的歌词草稿与创作记录。</Text>{works.length ? works.map(w=><View key={w.id} style={s.workManage}><TouchableOpacity style={{flex:1}} onPress={()=>onOpen(w)}><WorkRow work={w} onPress={()=>onOpen(w)}/></TouchableOpacity><TouchableOpacity style={s.deleteBtn} onPress={()=>Alert.alert('删除作品','确定删除这份作品吗？',[{text:'取消',style:'cancel'},{text:'删除',style:'destructive',onPress:()=>onDelete(w.id)}])}><Text style={s.deleteText}>删除</Text></TouchableOpacity></View>) : <View style={s.emptyCard}><Text style={s.emptyIcon}>♫</Text><Text style={s.emptyTitle}>还没有作品</Text><Text style={s.emptyText}>生成并保存歌词草稿后，会显示在这里。</Text></View>}</ScrollView>;
}
function WorkDetail({ work, onBack, onDelete, onEdit, onToggleFavorite, onShare }) {
  if(!work) return null;
  return <ScrollView style={s.page} contentContainerStyle={s.content}><Header title="作品详情" onBack={onBack}/><Text style={s.detailTitle}>{work.title}</Text><Text style={s.workMeta}>{work.style} · {work.status}</Text><Text style={s.detailLyrics}>{work.lyrics}</Text><PrimaryButton title="↗ 分享作品 / 歌词" onPress={()=>onShare(work)}/><PrimaryButton title={work.favorite ? "♥ 取消收藏" : "♡ 收藏作品"} onPress={()=>onToggleFavorite(work.id)}/><PrimaryButton title="编辑作品" onPress={()=>onEdit(work)}/><PrimaryButton title="删除这份作品" onPress={()=>Alert.alert('删除作品','确定删除吗？',[{text:'取消',style:'cancel'},{text:'删除',style:'destructive',onPress:()=>onDelete(work.id)}])}/></ScrollView>;
}
function Favorites({ works, onOpen, onBack }) {
  const favorites = works.filter(w => w.favorite);
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <Header title="我的收藏" onBack={onBack}/>
    <Text style={s.pageDesc}>你收藏的本地作品会集中显示在这里。</Text>
    {favorites.length ? favorites.map(w=><WorkRow key={w.id} work={w} onPress={()=>onOpen(w)}/>) :
      <View style={s.emptyCard}><Text style={s.emptyIcon}>♡</Text><Text style={s.emptyTitle}>还没有收藏</Text><Text style={s.emptyText}>打开一份作品，点击收藏，就能在这里快速找到它。</Text></View>}
  </ScrollView>;
}
function History({ works, onOpen, onBack }) {
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <Header title="创作记录" onBack={onBack}/>
    <Text style={s.pageDesc}>按最近保存顺序查看你的创作记录。</Text>
    <View style={s.historySummary}><Text style={s.historyCount}>{works.length}</Text><Text style={s.historyLabel}>份本地创作记录</Text></View>
    {works.length ? works.map(w=><WorkRow key={w.id} work={w} onPress={()=>onOpen(w)}/>) :
      <View style={s.emptyCard}><Text style={s.emptyIcon}>◷</Text><Text style={s.emptyTitle}>还没有创作记录</Text><Text style={s.emptyText}>保存歌词草稿或工具结果后，会自动显示在这里。</Text></View>}
  </ScrollView>;
}
function Settings({ nickname, onSave, onBack, backendSession, backendSyncMessage, onConnectBackend, onDisconnectBackend, onSyncBackend }) {
  const [draft, setDraft] = useState(nickname || '我的枝念');
  const [base, setBase] = useState(process.env.EXPO_PUBLIC_API_BASE_URL || '');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [connecting, setConnecting] = useState(false);
  const [backendMessage, setBackendMessage] = useState('');
  useEffect(() => { if (backendSession?.base) setBase(backendSession.base); }, [backendSession?.base]);
  return <ScrollView style={s.page} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
    <Header title="账户设置" onBack={onBack}/>
    <Text style={s.pageDesc}>设置个人昵称，并连接共享后端。连接后，作品与社区发布内容可以在用户端和管理后台之间同步。</Text>
    <View style={s.createBox}>
      <Text style={s.inputLabel}>个人昵称</Text>
      <TextInput value={draft} onChangeText={setDraft} style={s.settingsInput} placeholder="输入昵称" placeholderTextColor="#999" maxLength={24}/>
      <Text style={s.helperText}>昵称目前保存在当前设备。</Text>
      <PrimaryButton title="保存昵称" onPress={()=>{const value=draft.trim();if(!value){Alert.alert('昵称不能为空','请输入一个昵称。');return;}onSave(value);Alert.alert('已保存','昵称已更新。');}}/>
    </View>
    <View style={s.createBox}>
      <Text style={s.inputLabel}>共享后端连接</Text>
      {backendSession ? <View><Text style={s.helperText}>已连接：{backendSession.user?.displayName || backendSession.user?.username}（{backendSession.user?.role}）</Text><Text style={s.helperText}>服务地址：{backendSession.base}</Text><Text style={s.helperText}>{backendSyncMessage || '已连接共享后端。'}</Text><PrimaryButton title="重新同步本地数据" onPress={async()=>{setConnecting(true);try{await onSyncBackend();setBackendMessage('同步完成。');}catch(e){setBackendMessage(`同步失败：${e.message}`)}finally{setConnecting(false)}}}/><PrimaryButton title="断开后端连接" onPress={async()=>{await onDisconnectBackend();setBackendMessage('已断开连接；本机已有数据会保留。');}}/></View> : <View>
        <Text style={s.helperText}>请输入已运行的枝念音坊后端地址。手机连接电脑本地服务时，应填写电脑的局域网 IP，而不是 127.0.0.1；后端需监听 0.0.0.0。</Text>
        <Text style={[s.inputLabel,{marginTop:14}]}>后端地址</Text><TextInput value={base} onChangeText={setBase} style={s.settingsInput} autoCapitalize="none" autoCorrect={false} keyboardType="url" placeholder="http://192.168.1.10:8787"/>
        <Text style={[s.inputLabel,{marginTop:14}]}>账号</Text><TextInput value={username} onChangeText={setUsername} style={s.settingsInput} autoCapitalize="none" autoCorrect={false} autoComplete="username" placeholder="由超级管理员创建的账号"/>
        <Text style={[s.inputLabel,{marginTop:14}]}>密码</Text><TextInput value={password} onChangeText={setPassword} style={s.settingsInput} secureTextEntry autoComplete="password" placeholder="输入账号密码"/>
        <PrimaryButton title={connecting ? '正在连接…' : '登录并连接共享后端'} disabled={connecting} onPress={async()=>{setConnecting(true);setBackendMessage('');try{await onConnectBackend(base,username,password);setPassword('');setBackendMessage('连接成功，正在同步本地作品与社区发布内容。');}catch(e){setBackendMessage(e?.message || '连接失败，请检查地址、账号和网络。');}finally{setConnecting(false);}}}/>
      </View>}
      {backendMessage ? <Text style={s.helperText}>{backendMessage}</Text> : null}
      <Text style={s.helperText}>说明：本机后端目前是开发版；请勿将默认测试密码用于公网环境。真实 AI 音乐生成仍需单独配置供应商服务。</Text>
    </View>
  </ScrollView>;
}

export default function App() {
  const [current,setCurrent]=useState('home');
  const [subPage,setSubPage]=useState(null);
  const [toolMode,setToolMode]=useState('');
  const [works,setWorks]=useState([]);
  const [worksLoaded,setWorksLoaded]=useState(false);
  const [libraryTracks,setLibraryTracks]=useState([]);
  const [libraryLoaded,setLibraryLoaded]=useState(false);
  useEffect(() => { AsyncStorage.getItem('zhinian_music_library_v1').then(raw => { if(raw){try{setLibraryTracks(JSON.parse(raw));}catch(_){}} }).catch(()=>{}).finally(()=>setLibraryLoaded(true)); }, []);
  useEffect(() => { if(libraryLoaded) AsyncStorage.setItem('zhinian_music_library_v1',JSON.stringify(libraryTracks)).catch(()=>{}); }, [libraryTracks,libraryLoaded]);
  const addLibraryTrack = track => setLibraryTracks(prev => [track, ...prev.filter(t => t.uri !== track.uri)]);
  const removeLibraryTrack = id => { const track = libraryTracks.find(t => t.id === id); setLibraryTracks(prev => prev.filter(t => t.id !== id)); if (track?.uri && FileSystem.documentDirectory && track.uri.startsWith(`${FileSystem.documentDirectory}music-library/`)) FileSystem.deleteAsync(track.uri, { idempotent: true }).catch(() => {}); };
  const [selectedWork,setSelectedWork]=useState(null);
  const [nickname,setNickname]=useState('我的枝念');
  const [backendSession,setBackendSession]=useState(null);
  const [backendSyncMessage,setBackendSyncMessage]=useState('');
  useEffect(() => {
    AsyncStorage.getItem('zhinian_works_v1').then(raw => {
      if (raw) { try { setWorks(JSON.parse(raw)); } catch (_) {} }
    }).catch(() => {}).finally(() => setWorksLoaded(true));
  }, []);
  useEffect(() => {
    if (worksLoaded) AsyncStorage.setItem('zhinian_works_v1', JSON.stringify(works)).catch(() => {});
  }, [works, worksLoaded]);
  useEffect(() => { AsyncStorage.getItem('zhinian_nickname_v1').then(value => { if(value) setNickname(value); }).catch(() => {}); }, []);
  const saveNickname = (value) => { setNickname(value); AsyncStorage.setItem('zhinian_nickname_v1', value).catch(() => {}); };
  const [posts,setPosts]=useState(INITIAL_POSTS);
  const [postsLoaded,setPostsLoaded]=useState(false);
  const [category,setCategory]=useState('推荐');
  useEffect(() => { AsyncStorage.getItem('zhinian_community_v1').then(raw => { if(raw){try{setPosts(JSON.parse(raw));}catch(_){}} }).catch(()=>{}).finally(()=>setPostsLoaded(true)); }, []);
  useEffect(() => { if(postsLoaded) AsyncStorage.setItem('zhinian_community_v1',JSON.stringify(posts)).catch(()=>{}); }, [posts,postsLoaded]);
  useEffect(() => {
    AsyncStorage.getItem('zhinian_backend_session_v1').then(async raw => {
      if (!raw) return;
      const saved = JSON.parse(raw);
      const data = await backendRequest(saved.base, saved.token, '/api/auth/me');
      setBackendSession({ ...saved, user: data.user });
    }).catch(() => setBackendSyncMessage('暂时无法恢复后端连接；本机数据仍可使用，请检查网络后重新连接。'));
  }, []);
  useEffect(() => { if (backendSession && worksLoaded && postsLoaded) syncBackendData(backendSession).catch(e => setBackendSyncMessage(`后端已连接，但同步遇到问题：${e.message}`)); }, [backendSession, worksLoaded, postsLoaded]);
  const openTool=(name)=>{setToolMode(name);setSubPage('toolCreate');setCurrent('create');};
  const saveWork=(w)=>{
    const previous = works.find(old => old.id === w.id);
    const wasRemote = !!(w.remoteSynced || previous?.remoteSynced) || String(w.id || '').startsWith('work_');
    const item={...previous,...w,id:w.id || `w_${Date.now()}`,date:new Date().toLocaleDateString('zh-CN'),status:w.status || previous?.status || '歌词草稿',remoteSynced:false};
    setWorks(prev=>w.id ? prev.map(old=>old.id===w.id?item:old) : [item,...prev]);setSelectedWork(item);
    if (backendSession) (async()=>{
      const route = wasRemote && String(item.id).startsWith('work_') ? `/api/works/${encodeURIComponent(item.id)}` : '/api/works';
      const data = await backendRequest(backendSession.base, backendSession.token, route, { method: route === '/api/works' ? 'POST' : 'PATCH', body: { title: item.title, idea: item.idea || '', lyrics: item.lyrics || '', genre: item.style || item.genre || '流行', kind: item.kind || '歌词创作' } });
      const synced = mapBackendWork(data.item, { ...item, remoteSynced: true });
      setWorks(prev=>prev.map(old=>old.id===item.id?synced:old));setSelectedWork(prev=>prev?.id===item.id?synced:prev);setBackendSyncMessage('作品已同步到共享后端。');
    })().catch(e=>{setBackendSyncMessage(`作品已保存在本机，但同步失败：${e.message}`);Alert.alert('本地已保存','连接后端同步失败，作品仍保留在本机。请检查连接后重新打开账户设置。');});
  };
  const deleteWork=async(id)=>{const target=works.find(w=>w.id===id);if(String(id).startsWith('work_') && !backendSession){Alert.alert('需要连接后端','这份作品已同步到共享后端，请先连接后再删除，避免下次同步时重新出现。');return;}try{if(backendSession && String(id).startsWith('work_'))await backendRequest(backendSession.base,backendSession.token,`/api/works/${encodeURIComponent(id)}`,{method:'DELETE'});setWorks(prev=>prev.filter(w=>w.id!==id));if(selectedWork?.id===id)setSelectedWork(null);setSubPage(null);setCurrent('works');}catch(e){Alert.alert('删除失败',`后端删除未成功，本机作品已保留。${e.message}`)}};
  const toggleFavoriteWork=(id)=>{setWorks(prev=>prev.map(w=>w.id===id?{...w,favorite:!w.favorite}:w));setSelectedWork(prev=>prev?.id===id?{...prev,favorite:!prev.favorite}:prev);};
  const shareWork=(w)=>Share.share({title:w.title || '枝念音坊作品',message:`${w.title || '未命名作品'}\n风格：${w.style || '未设置'}\n\n${w.lyrics || ''}\n\n来自枝念音坊`});
  const openWork=(w)=>{setSelectedWork(w);setSubPage('detail');setCurrent('works');};
  const editWork=(w)=>{setSelectedWork(w);setSubPage('edit');setToolMode('编辑作品');setCurrent('create');};
  const toggleLike=(id)=>setPosts(prev=>prev.map(p=>p.id===id?{...p,liked:!p.liked,likes:Math.max(0,p.likes+(p.liked?-1:1))}:p));
  const addCommunityPost=(title)=>{const post={id:`p_${Date.now()}`,title,author:backendSession?.user?.displayName || nickname || '我',likes:0,comments:0,commentItems:[],category:'最新',liked:false,remoteSynced:false};setPosts(prev=>[post,...prev]);setCategory('最新');if(backendSession)(async()=>{const d=await backendRequest(backendSession.base,backendSession.token,'/api/posts',{method:'POST',body:{content:title}});const synced=mapBackendPost(d.item,post);setPosts(prev=>prev.map(old=>old.id===post.id?synced:old));setBackendSyncMessage('社区分享已发布到共享后端。')})().catch(e=>setBackendSyncMessage(`分享已保存在本机，但后端发布失败：${e.message}`));};
  const addCommunityComment=(id,text)=>setPosts(prev=>prev.map(p=>p.id===id?{...p,commentItems:[...(p.commentItems||[]),{id:`c_${Date.now()}`,author:'我',text}],comments:(p.commentItems||[]).length+1}:p));
  const connectBackend=async(base,username,password)=>{const normalized=String(base||'').trim().replace(/\/$/,'');const data=await backendRequest(normalized,'','/api/auth/login',{method:'POST',body:{username:String(username||'').trim(),password}});const session={base:normalized,token:data.token,user:data.user};await AsyncStorage.setItem('zhinian_backend_session_v1',JSON.stringify(session));setBackendSession(session);setBackendSyncMessage('已连接后端，准备同步数据。');};
  const disconnectBackend=async()=>{if(backendSession){try{await backendRequest(backendSession.base,backendSession.token,'/api/auth/logout',{method:'POST'});}catch{}}await AsyncStorage.removeItem('zhinian_backend_session_v1');setBackendSession(null);setBackendSyncMessage('已断开后端连接。');};
  const syncBackendNow=async()=>{if(!backendSession)throw new Error('尚未连接后端');await syncBackendData(backendSession)};
  async function syncBackendData(session){
    const localWorks=works;const localPosts=posts;
    const [remoteWorkData,remotePostData]=await Promise.all([backendRequest(session.base,session.token,'/api/works'),backendRequest(session.base,session.token,'/api/posts')]);
    let remoteWorks=[...(remoteWorkData.items||[])];const localByRemoteWork=new Map();const failedWorks=[];
    for(const local of localWorks){
      const idx=remoteWorks.findIndex(w=>w.id===local.id);
      if(idx>=0){
        if(!local.remoteSynced){try{const d=await backendRequest(session.base,session.token,`/api/works/${encodeURIComponent(local.id)}`,{method:'PATCH',body:{title:local.title,idea:local.idea||'',lyrics:local.lyrics||'',genre:local.style||local.genre||'流行',kind:local.kind||'歌词创作'}});remoteWorks[idx]=d.item;}catch(e){failedWorks.push(local);}}
        localByRemoteWork.set(remoteWorks[idx]?.id||local.id,local);
      }else{
        if(local.remoteSynced){failedWorks.push(local);continue;}
        try{const d=await backendRequest(session.base,session.token,'/api/works',{method:'POST',body:{title:local.title||'未命名作品',idea:local.idea||'',lyrics:local.lyrics||'',genre:local.style||local.genre||'流行',kind:local.kind||'歌词创作'}});remoteWorks.unshift(d.item);localByRemoteWork.set(d.item.id,local);}catch(e){failedWorks.push(local);}
      }
    }
    const failedWorkById=new Map(failedWorks.map(w=>[w.id,w]));
    const mappedWorks=remoteWorks.map(w=>{const failed=failedWorkById.get(w.id);if(failed)return {...mapBackendWork(w,failed),title:failed.title,idea:failed.idea,lyrics:failed.lyrics,style:failed.style,genre:failed.genre,kind:failed.kind,status:failed.status,remoteSynced:false};return mapBackendWork(w,localWorks.find(l=>l.id===w.id)||localByRemoteWork.get(w.id)||{});});
    setWorks([...mappedWorks,...failedWorks.filter(l=>!mappedWorks.some(w=>w.id===l.id))]);
    let remotePosts=[...(remotePostData.items||[])];const localByRemotePost=new Map();const failedPosts=[];
    for(const local of localPosts){
      if(['p1','p2','p3'].includes(local.id))continue;
      const idx=remotePosts.findIndex(p=>p.id===local.id);
      if(idx>=0){localByRemotePost.set(local.id,local);continue;}
      if(local.remoteSynced)continue;
      try{const d=await backendRequest(session.base,session.token,'/api/posts',{method:'POST',body:{content:local.title||'创作分享'}});remotePosts.unshift(d.item);localByRemotePost.set(d.item.id,local);}catch(e){failedPosts.push(local);}
    }
    const mappedPosts=remotePosts.map(p=>mapBackendPost(p,localPosts.find(l=>l.id===p.id)||localByRemotePost.get(p.id)||{}));
    setPosts([...mappedPosts,...failedPosts.filter(l=>!mappedPosts.some(p=>p.id===l.id))]);setBackendSyncMessage('作品与社区发布内容同步完成；点赞、评论仍为本机数据。');
  }
  const go=(key,mode='')=>{setCurrent(key);setSubPage(null);setToolMode(mode);};
  let page;
  if(current==='home') page=<Home go={go} works={works} openWork={openWork}/>;
  else if(current==='create') page=<Create key={subPage==='edit' ? `edit-${selectedWork?.id}` : `new-${toolMode}`} initialMode={toolMode} initialWork={subPage==='edit'?selectedWork:null} onSave={saveWork} onBack={()=>{if(subPage==='edit'){setSubPage('detail');setCurrent('works');}else go('home');}} backendSession={backendSession}/>;
  else if(current==='tools') page=<Tools openTool={openTool} onSave={saveWork}/>;
  else if(current==='music') page=<MusicLibrary tracks={libraryTracks} onAddTrack={addLibraryTrack} onRemoveTrack={removeLibraryTrack} works={works} onBack={()=>go('home')}/>;
  else if(current==='community') page=<Community posts={posts} toggleLike={toggleLike} category={category} setCategory={setCategory} onAddPost={addCommunityPost} onAddComment={addCommunityComment} backendConnected={!!backendSession}/>;
  else if(current==='me') page=<Me go={(key)=>{setCurrent(key);setSubPage(key);}} works={works} nickname={nickname}/>;
  else if(current==='works'&&subPage==='detail') page=<WorkDetail work={selectedWork} onBack={()=>{setSubPage(null);setCurrent('works');}} onDelete={deleteWork} onEdit={editWork} onToggleFavorite={toggleFavoriteWork} onShare={shareWork}/>;
  else if(current==='works') page=<Works works={works} onOpen={openWork} onDelete={deleteWork} onBack={()=>go('me')}/>;
  else if(current==='favorites') page=<Favorites works={works} onOpen={openWork} onBack={()=>go('me')}/>;
  else if(current==='history') page=<History works={works} onOpen={openWork} onBack={()=>go('me')}/>;
  else page=<Settings nickname={nickname} onSave={saveNickname} onBack={()=>go('me')} backendSession={backendSession} backendSyncMessage={backendSyncMessage} onConnectBackend={connectBackend} onDisconnectBackend={disconnectBackend} onSyncBackend={syncBackendNow}/>;
  return <SafeAreaView style={s.container}><View style={s.main}>{page}</View><View style={s.bottomNav}>{NAV.map(item=>{const active=current===item.key;return <TouchableOpacity key={item.key} style={s.navItem} onPress={()=>go(item.key)}><Text style={[s.navIcon,active&&s.navActive]}>{item.icon}</Text><Text style={[s.navText,active&&s.navActive]}>{item.title}</Text></TouchableOpacity>;})}</View></SafeAreaView>;
}

const s=StyleSheet.create({
 container:{flex:1,backgroundColor:'#F7F7F5'},main:{flex:1},page:{flex:1,backgroundColor:'#F7F7F5'},content:{padding:20,paddingBottom:35},
 header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:22},brand:{fontSize:29,fontWeight:'800',color:'#191919',letterSpacing:1},subBrand:{fontSize:12,color:'#888',marginTop:5},avatar:{width:42,height:42,borderRadius:21,backgroundColor:'#191919',alignItems:'center',justifyContent:'center'},avatarText:{color:'#FFF',fontSize:17,fontWeight:'700'},
 hero:{backgroundColor:'#191919',borderRadius:24,padding:25,marginBottom:28},heroSmall:{color:'#BEBEBE',fontSize:13,marginBottom:10},heroTitle:{color:'#FFF',fontSize:27,fontWeight:'800',marginBottom:12},heroDesc:{color:'#BDBDBD',fontSize:14,lineHeight:22},heroButton:{backgroundColor:'#FFF',alignSelf:'flex-start',paddingVertical:12,paddingHorizontal:18,borderRadius:14,marginTop:22},heroButtonText:{color:'#191919',fontWeight:'700'},
 sectionTitle:{fontSize:19,fontWeight:'800',color:'#222',marginBottom:14,marginTop:3},sectionRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},linkText:{fontSize:13,color:'#555',fontWeight:'700'},quickGrid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between',marginBottom:27},quickCard:{width:'48%',backgroundColor:'#FFF',borderRadius:18,padding:16,marginBottom:12},quickIcon:{width:38,height:38,borderRadius:12,backgroundColor:'#F0F0ED',alignItems:'center',justifyContent:'center',marginBottom:13},quickIconText:{fontSize:19,color:'#222'},quickTitle:{fontSize:15,fontWeight:'700',color:'#222'},quickDesc:{fontSize:11,color:'#999',marginTop:5,lineHeight:17},
 emptyCard:{backgroundColor:'#FFF',borderRadius:20,padding:25,alignItems:'center',marginBottom:27},emptyIcon:{fontSize:31,marginBottom:8},emptyTitle:{fontSize:17,fontWeight:'700',color:'#222'},emptyText:{fontSize:12,color:'#999',textAlign:'center',marginTop:7,lineHeight:19},smallButton:{marginTop:17,backgroundColor:'#191919',paddingVertical:10,paddingHorizontal:18,borderRadius:12},smallButtonText:{color:'#FFF',fontSize:13,fontWeight:'700'},communityCard:{backgroundColor:'#EAEAE5',borderRadius:20,padding:20},communityTitle:{fontSize:17,fontWeight:'800',color:'#222'},communityText:{fontSize:13,color:'#777',lineHeight:20,marginTop:8},
 pageHeader:{flexDirection:'row',alignItems:'center',minHeight:38,marginTop:4},pageTitle:{fontSize:27,fontWeight:'800',color:'#191919'},backBtn:{marginRight:12,paddingVertical:5},backText:{fontSize:14,color:'#666',fontWeight:'700'},pageDesc:{fontSize:13,color:'#888',marginTop:7,marginBottom:24},createBox:{backgroundColor:'#FFF',borderRadius:21,padding:18,marginBottom:25},inputLabel:{fontSize:15,fontWeight:'700',marginBottom:10,color:'#222'},input:{minHeight:115,borderRadius:15,backgroundColor:'#F5F5F2',padding:15,textAlignVertical:'top',fontSize:14,color:'#222'},chipRow:{flexDirection:'row',flexWrap:'wrap',gap:8},chip:{paddingVertical:9,paddingHorizontal:13,borderRadius:18,backgroundColor:'#F2F2EF',marginBottom:3},chipActive:{backgroundColor:'#191919'},chipText:{fontSize:12,color:'#555'},chipTextActive:{color:'#FFF',fontWeight:'700'},primaryBtn:{backgroundColor:'#191919',paddingVertical:15,borderRadius:15,alignItems:'center',marginTop:16},primaryBtnText:{color:'#FFF',fontWeight:'800',fontSize:14},helperText:{fontSize:11,color:'#999',lineHeight:17,marginTop:10},lyricsCard:{backgroundColor:'#FFF',borderRadius:20,padding:18,marginBottom:20},titleInput:{fontSize:18,fontWeight:'800',paddingVertical:10,color:'#222',borderBottomWidth:1,borderBottomColor:'#EEE',marginBottom:12},lyricsInput:{minHeight:300,fontSize:14,lineHeight:24,color:'#333',textAlignVertical:'top'},
 settingsInput:{minHeight:50,borderRadius:13,backgroundColor:'#F5F5F2',paddingHorizontal:14,fontSize:15,color:'#222'},historySummary:{backgroundColor:'#EAEAE5',borderRadius:16,padding:18,flexDirection:'row',alignItems:'baseline',marginBottom:16},historyCount:{fontSize:25,fontWeight:'800',color:'#222',marginRight:10},historyLabel:{fontSize:13,color:'#666'},toolResultInput:{minHeight:180,fontSize:14,lineHeight:23,color:'#333',textAlignVertical:'top',backgroundColor:'#F7F7F5',borderRadius:13,padding:14},toolSection:{marginBottom:23},toolTitle:{fontSize:16,fontWeight:'800',marginBottom:10},toolGrid:{backgroundColor:'#FFF',borderRadius:18,overflow:'hidden'},toolItem:{minHeight:54,paddingHorizontal:15,borderBottomWidth:1,borderBottomColor:'#F0F0F0',flexDirection:'row',alignItems:'center'},toolNumber:{fontSize:11,color:'#AAA',width:35},toolItemText:{flex:1,fontSize:14,color:'#333'},arrow:{fontSize:24,color:'#999'},
 tabs:{flexDirection:'row',backgroundColor:'#FFF',padding:5,borderRadius:14,marginBottom:15},tabBtn:{flex:1,alignItems:'center',paddingVertical:9,borderRadius:10},tabBtnActive:{backgroundColor:'#191919'},tabBtnText:{color:'#999',fontSize:13},tabBtnTextActive:{color:'#FFF',fontWeight:'700'},postCard:{backgroundColor:'#FFF',borderRadius:18,padding:14,marginBottom:12,flexDirection:'row'},postCover:{width:75,height:75,borderRadius:15,backgroundColor:'#E9E9E5',justifyContent:'center',alignItems:'center',marginRight:13},postMusic:{fontSize:27},postTitle:{fontSize:14,fontWeight:'700',color:'#222',marginTop:2},postAuthor:{fontSize:11,color:'#999',marginTop:7},postStats:{flexDirection:'row',gap:13,marginTop:10},stat:{fontSize:11,color:'#999'},
 profile:{alignItems:'center',paddingTop:10,paddingBottom:25},bigAvatar:{width:82,height:82,borderRadius:41,backgroundColor:'#191919',justifyContent:'center',alignItems:'center',marginBottom:13},bigAvatarText:{color:'#FFF',fontSize:31,fontWeight:'800'},profileName:{fontSize:21,fontWeight:'800'},profileDesc:{color:'#999',fontSize:12,marginTop:6},statsBox:{backgroundColor:'#FFF',borderRadius:18,paddingVertical:17,flexDirection:'row',marginBottom:16},statBoxItem:{flex:1,alignItems:'center'},statBig:{fontSize:18,fontWeight:'800'},statLabel:{fontSize:11,color:'#999',marginTop:5},menuCard:{backgroundColor:'#FFF',borderRadius:18,overflow:'hidden'},menuItem:{height:55,paddingHorizontal:17,borderBottomWidth:1,borderBottomColor:'#F0F0F0',flexDirection:'row',alignItems:'center'},menuItemText:{flex:1,fontSize:14,color:'#333'},
 workRow:{backgroundColor:'#FFF',borderRadius:17,padding:13,flexDirection:'row',alignItems:'center',marginBottom:10},workCover:{width:58,height:58,borderRadius:13,backgroundColor:'#EAEAE5',alignItems:'center',justifyContent:'center',marginRight:13},workTitle:{fontSize:14,fontWeight:'800',color:'#222'},workMeta:{fontSize:11,color:'#999',marginTop:5},workManage:{flexDirection:'row',alignItems:'center'},deleteBtn:{padding:10,marginLeft:6},deleteText:{color:'#B34B5A',fontSize:12,fontWeight:'700'},detailTitle:{fontSize:24,fontWeight:'800',color:'#222',marginTop:20},detailLyrics:{fontSize:14,lineHeight:25,color:'#333',backgroundColor:'#FFF',borderRadius:18,padding:18,marginTop:18,marginBottom:18},
 communityComposeBtn:{backgroundColor:'#191919',paddingHorizontal:14,paddingVertical:9,borderRadius:12},communityComposeText:{color:'#FFF',fontSize:13,fontWeight:'700'},modalShade:{flex:1,backgroundColor:'rgba(0,0,0,0.42)',justifyContent:'center',padding:22},modalCard:{backgroundColor:'#FFF',borderRadius:22,padding:20,maxHeight:'85%'},modalTitle:{fontSize:19,fontWeight:'800',color:'#222',marginBottom:15},modalInput:{minHeight:115,backgroundColor:'#F5F5F2',borderRadius:14,padding:14,textAlignVertical:'top',fontSize:14,color:'#222'},modalHint:{fontSize:11,color:'#999',lineHeight:17,marginTop:10,marginBottom:14},modalActions:{flexDirection:'row',justifyContent:'flex-end',gap:10},modalSecondary:{paddingVertical:12,paddingHorizontal:18,borderRadius:12,backgroundColor:'#F1F1EE'},modalSecondaryText:{color:'#555',fontWeight:'700'},modalPrimary:{paddingVertical:13,paddingHorizontal:18,borderRadius:12,backgroundColor:'#191919',alignItems:'center',marginTop:10},modalPrimaryText:{color:'#FFF',fontWeight:'700'},modalClose:{color:'#777',fontSize:13,padding:4},modalPostTitle:{fontSize:13,color:'#777',marginBottom:10},commentList:{maxHeight:260,minHeight:90},commentRow:{paddingVertical:10,borderBottomWidth:1,borderBottomColor:'#F0F0F0'},commentAuthor:{fontSize:12,fontWeight:'700',color:'#555',marginBottom:4},commentBody:{fontSize:14,color:'#333',lineHeight:20},commentInput:{minHeight:45,backgroundColor:'#F5F5F2',borderRadius:12,paddingHorizontal:13,paddingVertical:10,color:'#222',marginTop:12}, bottomNav:{height:68,backgroundColor:'#FFF',borderTopWidth:1,borderTopColor:'#EAEAEA',flexDirection:'row',alignItems:'center'},navItem:{flex:1,alignItems:'center',justifyContent:'center'},navIcon:{fontSize:20,color:'#999',marginBottom:3},navText:{fontSize:10,color:'#999'},navActive:{color:'#191919',fontWeight:'800'}
});
